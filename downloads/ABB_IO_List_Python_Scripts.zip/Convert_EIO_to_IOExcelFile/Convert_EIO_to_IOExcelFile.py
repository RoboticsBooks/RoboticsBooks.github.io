# Author : Guillaume OLIVIER - IndusProgramming.com
# This script is able to generate IO_List Excel and CSV files from a EIO.cfg file
# Input file  : from/EIO.cfg
# Ouput file : to/IO_List.xlsx AND to/IO_List_CSV.csv

import os
from re import split
import re
import csv
import openpyxl


def camelize(string):
    return ''.join(a.capitalize() for a in split('([^a-zA-Z0-9])', string))

#Clean files in folder
def cleanFiles(string):
    try:
        for file in os.scandir(string):
            os.remove(file.path)
    except OSError as e:  # if failed, report it back to the user ##
        print("Error: %s - %s." % (e.filename, e.strerror))


print('Script Starting')

script_dir = os.path.dirname(__file__)  # <-- absolute dir the script is in

# Clean file / don't clean the file because we fill the excel file with data
#cleanFiles(os.path.join(script_dir, "to/"))

EIOs = []
EIO = {}

EIOs_lines = []
EIO_line = ''

# Open EIO.cfg file
fEIO = open(os.path.join(
    script_dir, "from/EIO.cfg"), 'r')

try:
    # Get IO declaration from EIO.cfg
    lines = fEIO.readlines() 
    for i in range(len(lines)):
        if '-Name' in lines[i] and '-SignalType' in lines[i]:
            if '\\' in lines[i]:
                EIO_line = lines[i] + lines[i+1]
            else:
                EIO_line = lines[i]
            EIOs_lines.append(EIO_line)

    # Error : no EIOs Signal Found
    if len(EIOs_lines)==0:
        raise Exception('Error : no EIOs Signal Found')
        
    # Extract data from declaration
    for line in EIOs_lines:
        EIO['Name'] = ''
        EIO['SignalType'] = ''
        EIO['Device'] = ''
        EIO['DeviceMap_Start'] = 0
        EIO['DeviceMap_End'] = 0
        #Name        
        matches = re.findall(r'-Name "(.+?)"',line)
        if len(matches)>0:
            EIO['Name'] = matches[0]
        #SignalType        
        matches = re.findall(r'-SignalType "(.+?)"',line)
        if len(matches)>0:
            EIO['SignalType'] = matches[0]
        #Device        
        matches = re.findall(r'-Device "(.+?)"',line)
        if len(matches)>0:
            EIO['Device'] = matches[0]
        #DeviceMap
        if EIO['SignalType']=='GI' or EIO['SignalType']=='GO':
            #DeviceMap Start        
            matches = re.findall(r'-DeviceMap "(\d+?)-\d+?"',line)
            if len(matches)>0:
                EIO['DeviceMap_Start'] = int(matches[0])
            #DeviceMap End        
            matches = re.findall(r'-DeviceMap "\d+?-(\d+?)"',line)
            if len(matches)>0:
                EIO['DeviceMap_End'] = int(matches[0])
        else:
            #DeviceMap Start        
            matches = re.findall(r'-DeviceMap "(\d+?)"',line)
            if len(matches)>0:
                EIO['DeviceMap_Start'] = int(matches[0])   
        EIOs.append(EIO.copy())

    # Sort EIO by Device, SignalType, DeviceMap_Start
    EIOs_Sorted = sorted(EIOs, key=lambda d: (d['Device'], d['SignalType'], d['DeviceMap_Start'])) 
    
    keys = EIOs_Sorted[0].keys()
    with open(
        os.path.join(script_dir, "to/IO_List_CSV.csv"), 'w', newline='') as output_file:
        dict_writer = csv.DictWriter(output_file, keys)
        dict_writer.writeheader()
        dict_writer.writerows(EIOs_Sorted)

    # Write into existing Excel file
    file_name = os.path.join(script_dir, "to/IO_List.xlsx")

    # Open IO_List.xlsx excel file
    wb = openpyxl.load_workbook(file_name)

    # Select the worksheet where you want to insert the data (assuming the sheet name is 'Sheet1')
    ws = wb['IO_List']

    # Delete content below row #3
    for row in ws['A3:R500']:
        for cell in row:
            cell.value = None

    # Get the next available row in the worksheet
    DI_row = 3
    DO_row = 3
    GI_row = 3
    GO_row = 3

    # Loop through the list of dictionaries and insert data into the Excel file
    for item in EIOs_Sorted:
        #Digital inputs
        if item['SignalType']=='DI':
            ws.cell(row=DI_row, column=1, value=item['Name'])
            ws.cell(row=DI_row, column=2, value=item['Device'])
            ws.cell(row=DI_row, column=3, value=item['DeviceMap_Start'])
            DI_row += 1
        elif item['SignalType']=='DO':
            ws.cell(row=DO_row, column=5, value=item['Name'])
            ws.cell(row=DO_row, column=6, value=item['Device'])
            ws.cell(row=DO_row, column=7, value=item['DeviceMap_Start'])
            DO_row += 1
        elif item['SignalType']=='GI':
            ws.cell(row=GI_row, column=9, value=item['Name'])
            ws.cell(row=GI_row, column=10, value=item['Device'])
            ws.cell(row=GI_row, column=11, value=item['DeviceMap_Start'])
            ws.cell(row=GI_row, column=12, value=item['DeviceMap_End'])
            GI_row += 1
        elif item['SignalType']=='GO':
            ws.cell(row=GO_row, column=14, value=item['Name'])
            ws.cell(row=GO_row, column=15, value=item['Device'])
            ws.cell(row=GO_row, column=16, value=item['DeviceMap_Start'])
            ws.cell(row=GO_row, column=17, value=item['DeviceMap_End'])
            GO_row += 1

    # Save the changes to the Excel file
    wb.save(file_name)

    print('Script Finished')

except Exception as e:
    print(e)

finally:
    fEIO.close()
