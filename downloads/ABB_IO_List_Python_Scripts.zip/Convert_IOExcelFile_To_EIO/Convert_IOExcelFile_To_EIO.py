# Author : Guillaume OLIVIER - IndusProgramming.com
# This script is able to generate EIO.cfg file from an IO_List Excel Files 
# Input file  : from/IO_List.xlsx
# Ouput file : to/EIO.cfg

import os
from re import split
import openpyxl

def camelize(string):
    return ''.join(a.capitalize() for a in split('([^a-zA-Z0-9])', string))

#Clean files in folder
def cleanFiles(string):
    try:
        for file in os.scandir(string):
            os.remove(file.path)
    except OSError as e:  # if failed, report it back to the user ##
        print("Error: %s - %s." % (e.filename, e.strerror))

#Create EIO lines in EIO.cfg
def createEIO(EIOs):
    temp = ''

    temp = temp + '''#
EIO_SIGNAL:
''' 
    for EIO in EIOs:
        Name = EIO.get('Name');
        Device = EIO.get('Device')
        SignalType = EIO.get('SignalType')
        DeviceMap = EIO.get('DeviceMap')

        temp = temp + f'-Name "{Name}" -SignalType "{SignalType}" -Device "{Device}" -DeviceMap "{DeviceMap}"\n' 

    return temp;


print('Script Starting')

script_dir = os.path.dirname(__file__)  # <-- absolute dir the script is in

# Clean file
cleanFiles(os.path.join(script_dir, "to/"))

EIOs = []
EIO = {}

# Create EIO.cfg file
fEIO = open(os.path.join(
    script_dir, "to/EIO.cfg"), 'w')

try:
    # Open IO_List.xlsx excel file    
    wb = openpyxl.load_workbook(os.path.join(
        script_dir, 'from/IO_List.xlsx'))

    # Select sheet
    ws = wb['IO_List']

    # Digital inputs
    for i in range(3, ws.max_row+1):
        EIO['Name'] = ws.cell(row=i, column=1).value
        if EIO['Name'] is not None:
            EIO['Device'] = ws.cell(row=i, column=2).value
            EIO['SignalType'] = 'DI'
            EIO['DeviceMap'] = ws.cell(row=i, column=3).value
            EIOs.append(EIO.copy())

    # Digital outputs
    for i in range(3, ws.max_row+1):
        EIO['Name'] = ws.cell(row=i, column=5).value
        if EIO['Name'] is not None:
            EIO['Device'] = ws.cell(row=i, column=6).value
            EIO['SignalType'] = 'DO'
            EIO['DeviceMap'] = ws.cell(row=i, column=7).value
            EIOs.append(EIO.copy())

    # Group inputs
    for i in range(3, ws.max_row+1):
        EIO['Name'] = ws.cell(row=i, column=9).value
        if EIO['Name'] is not None:
            EIO['Device'] = ws.cell(row=i, column=10).value
            EIO['SignalType'] = 'GI'
            EIO['DeviceMap'] = str(ws.cell(row=i, column=11).value) + '-' + str(ws.cell(row=i, column=12).value)
            EIOs.append(EIO.copy())

    # Group outputs
    for i in range(3, ws.max_row+1):
        EIO['Name'] = ws.cell(row=i, column=14).value
        if EIO['Name'] is not None:
            EIO['Device'] = ws.cell(row=i, column=15).value
            EIO['SignalType'] = 'GO'
            EIO['DeviceMap'] = str(ws.cell(row=i, column=16).value) + '-' + str(ws.cell(row=i, column=17).value)
            EIOs.append(EIO.copy())        

    # Write to EIO.cfg
    fEIO.write(createEIO(EIOs))

    print('Script Finished')

except Exception as e:
    print(e)

finally:
    fEIO.close()
