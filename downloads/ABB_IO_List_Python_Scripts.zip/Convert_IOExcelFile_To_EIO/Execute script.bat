@echo off
echo --------------
echo Executing script ...
python Convert_IOExcelFile_To_EIO.py %*
echo Done
echo --------------
@pause
