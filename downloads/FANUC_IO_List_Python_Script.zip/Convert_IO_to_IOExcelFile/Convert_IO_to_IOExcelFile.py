
import os
import requests
from bs4 import BeautifulSoup
import re
import openpyxl


print('Script Starting')

script_dir = os.path.dirname(__file__)  # <-- absolute dir the script is in

IOs = []
IO = {}

try:

    # Adresse du site Internet
    IPAddress = input("Robot IP Address (default if empty is 127.0.0.1) :")
    if len(IPAddress) == 0:
        IPAddress = "127.0.0.1"
    url = "http://" + IPAddress + "/MD/IOSTATE.DG"
    # Exécuter la requête GET
    response = requests.get(url)
    # Error : requete http
    if response.status_code!=200:
        raise Exception('Error : Http request failed, check IP Address')
    
    # Parser le document HTML BeautifulSoup obtenu à partir du code source
    html = BeautifulSoup(response.text, 'html.parser')

    #Get IO from IOSTATE file
    for line in html.getText().splitlines():
        matches = re.findall(r'([A-Z]+)\[.+?(\d+)].+[A-Za-z0-9]+  (.+)',line)
        if len(matches)>0:
            type = matches[0][0]
            #print(matches[0])
            IO['SignalType'] = matches[0][0]
            IO['Address'] = matches[0][1]
            IO['Name'] = matches[0][2]
            #print(IO)
            IOs.append(IO.copy())

    # Error : no EIOs Signal Found
    if len(IOs)==0:
        raise Exception('Error : no IOs Found')
    
    # Write into existing Excel file
    file_name = os.path.join(script_dir, "to/IO_List.xlsx")

    # Open IO_List.xlsx excel file
    wb = openpyxl.load_workbook(file_name)

    # Select the worksheet where you want to insert the data (assuming the sheet name is 'Sheet1')
    ws = wb['IO_List']

    # Delete content below row #3
    for row in ws['A3:Z500']:
        for cell in row:
            cell.value = None

    # Get the next available row in the worksheet
    DI_row = 3
    DO_row = 3
    GI_row = 3
    GO_row = 3
    UI_row = 3
    UO_row = 3
    RI_row = 3
    RO_row = 3

    # Loop through the list of dictionaries and insert data into the Excel file
    for item in IOs:
        #Digital inputs
        if item['SignalType']=='DIN':
            ws.cell(row=DI_row, column=1, value=item['Name'])
            ws.cell(row=DI_row, column=2, value=float(item['Address']))
            DI_row += 1
        elif item['SignalType']=='DOUT':
            ws.cell(row=DO_row, column=4, value=item['Name'])
            ws.cell(row=DO_row, column=5, value=float(item['Address']))
            DO_row += 1
        elif item['SignalType']=='GIN':
            ws.cell(row=GI_row, column=7, value=item['Name'])
            ws.cell(row=GI_row, column=8, value=float(item['Address']))
            GI_row += 1
        elif item['SignalType']=='GOUT':
            ws.cell(row=GO_row, column=10, value=item['Name'])
            ws.cell(row=GO_row, column=11, value=float(item['Address']))
            GO_row += 1
        elif item['SignalType']=='UI':
            ws.cell(row=UI_row, column=13, value=item['Name'])
            ws.cell(row=UI_row, column=14, value=float(item['Address']))
            UI_row += 1
        elif item['SignalType']=='UO':
            ws.cell(row=UO_row, column=16, value=item['Name'])
            ws.cell(row=UO_row, column=17, value=float(item['Address']))
            UO_row += 1
        elif item['SignalType']=='RI':
            ws.cell(row=RI_row, column=19, value=item['Name'])
            ws.cell(row=RI_row, column=20, value=float(item['Address']))
            RI_row += 1
        elif item['SignalType']=='RO':
            ws.cell(row=RO_row, column=22, value=item['Name'])
            ws.cell(row=RO_row, column=23, value=float(item['Address']))
            RO_row += 1

    # Save the changes to the Excel file
    wb.save(file_name)

    print('Script Finished')


except Exception as e:
    print(e)
